function FourthComponent() {
    return (
      <div className="App">
       <h1>Footer</h1>
      </div>
    );
  }
export default FourthComponent;