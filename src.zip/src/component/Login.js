import {Link} from 'react-router-dom';

function Login() {
    return(
        <div>
            This is navigation
            <Link to='/counter'>counter</Link>
        </div>
    );
}
export default Login;
