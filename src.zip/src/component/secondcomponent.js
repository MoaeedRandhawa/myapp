import { Link } from "react-router-dom";

function Secondcomponent(props) {
    return (
        <div style={{ background: props.background,width:props.width,height:props.height,justifyContent: props.justifyContent,textAlign:props.textAlign,paddingTop:props.paddingTop}}>
          <Link to='/Third'>thirdcomponent</Link>

        </div>

    );
  }
  

  

export default Secondcomponent;