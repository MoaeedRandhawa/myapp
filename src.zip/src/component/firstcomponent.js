import { Link } from "react-router-dom";


function Firstcomponent(props) {
    return (

        <div style={{ background: props.color,width:props.width,height:props.height}}>
            <Link to='/Second'>Secondcomponent</Link>
        </div>

    );
  }
  

  

export default Firstcomponent;