

function Thirdcomponent(props) {
    return (

        <div style={{ background: props.background,width:props.width,height:props.height }}>
          <p>Footer</p>

        </div>
    );
  }
  

  

export default Thirdcomponent;