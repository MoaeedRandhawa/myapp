

import {BrowserRouter} from 'react-router-dom';
import Path from './Routes';

function App() {
  return (
    <div>
    <BrowserRouter>
    <Path/>
    </BrowserRouter>
    </div>
  );
}

export default App;
